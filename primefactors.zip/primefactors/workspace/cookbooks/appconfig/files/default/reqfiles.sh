sudo apt-get update
sudo apt-get upgrade  # Update software
sudo apt-get install libsqlite3-dev -y # Install packages
sudo apt-get install ruby-railties-4.0 -y
#sudo chmod 677 /prime_factors_kata/Gemfile.lock
#sudo apt-get install nodejs -y
#sudo mkdir tmp
#sudo chmod 677 -R /prime_factors_kata/tmp/
#sudo chmod 677 -R /prime_factors_kata/log/
#sudo chmod 677 -R /prime_factors_kata/db/
#cd /prime_factors_kata/bin
#rake db:migrate
#sudo service primfact.sh start