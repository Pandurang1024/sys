require 'spec_helper'

describe 'build-essential::_solaris2' do
  pending 'fauxhai data for solaris2'
end
