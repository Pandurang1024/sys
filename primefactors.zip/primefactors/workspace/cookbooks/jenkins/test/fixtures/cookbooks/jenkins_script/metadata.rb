name 'jenkins_script'
depends 'jenkins'
