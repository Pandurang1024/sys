name 'jenkins_user'
depends 'jenkins'
